from .model import FrogFactorAuthenticator


def load_model():
    return FrogFactorAuthenticator()
